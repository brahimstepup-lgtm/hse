/* Service HSE — formulaires partagés : onglets Commande/Réservation ↔ Devis.
   Les demandes partent vers le même Google Apps Script que les commandes. */
(function(){
const SCRIPT_URL="https://script.google.com/macros/s/AKfycbxXZ_CLYCB-sP9AhbAqqzVslp6hbGSXF0tJUyb7aSIqk-9ohG-Kv_1cWdK2vdWsOCVP/exec";
const WILAYAS=["أدرار","الشلف","الأغواط","أم البواقي","باتنة","بجاية","بسكرة","بشار","البليدة","البويرة","تمنراست","تبسة","تلمسان","تيارت","تيزي وزو","الجزائر","الجلفة","جيجل","سطيف","سعيدة","سكيكدة","سيدي بلعباس","عنابة","قالمة","قسنطينة","المدية","مستغانم","المسيلة","معسكر","ورقلة","وهران","البيض","إليزي","برج بوعريريج","بومرداس","الطارف","تندوف","تيسمسيلت","الوادي","خنشلة","سوق أهراس","تيبازة","ميلة","عين الدفلى","النعامة","عين تموشنت","غرداية","غليزان","تيميمون","برج باجي مختار","أولاد جلال","بني عباس","عين صالح","عين قزام","تقرت","جانت","المغير","المنيعة","آفلو","الأبيض سيدي الشيخ","العريشة","القنطرة","بريكة","بوسعادة","بئر العاتر","قصر البخاري","قصر الشلالة","عين وسارة","مسعد"];
function fillWilaya(sel){if(!sel||sel.options.length>1)return;WILAYAS.forEach((w,i)=>{const n=String(i+1).padStart(2,"0");const o=document.createElement("option");o.value=n+" - "+w;o.textContent=n+" - "+w;sel.appendChild(o);});}
function cleanPhone(v){v=v.replace(/[٠-٩]/g,d=>"٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/[^\d+]/g,"");
  if(v.startsWith("+213"))v="0"+v.slice(4);else if(v.startsWith("00213"))v="0"+v.slice(5);else if(v.startsWith("213")&&v.length===12)v="0"+v.slice(3);return v;}
function mark(el,ok){el.classList.toggle("invalid",!ok);return ok;}
async function send(data){await fetch(SCRIPT_URL,{method:"POST",mode:"no-cors",body:new URLSearchParams(data)});}

/* Onglets : boutons [data-mode] dans .mode, panneaux [data-panel] */
function initModes(root){
  const tabs=[...root.querySelectorAll(".mode [data-mode]")],panels=[...root.querySelectorAll("[data-panel]")];
  function show(m){tabs.forEach(t=>{const on=t.dataset.mode===m;t.classList.toggle("on",on);t.setAttribute("aria-selected",on);});
    panels.forEach(p=>p.hidden=p.dataset.panel!==m);}
  tabs.forEach(t=>t.addEventListener("click",()=>show(t.dataset.mode)));
  document.querySelectorAll("[data-open]").forEach(a=>a.addEventListener("click",e=>{show(a.dataset.open);}));
  if(location.hash==="#devis"){show("devis");setTimeout(()=>root.scrollIntoView({block:"start"}),60);}
  return show;
}
function finish(root,box,name,phone){
  root.querySelector(".mode")&&(root.querySelector(".mode").hidden=true);
  root.querySelectorAll("[data-panel]").forEach(p=>p.hidden=true);
  box.querySelector(".dn").textContent=name;box.querySelector(".dp").textContent=phone;box.hidden=false;box.style.display="block";box.scrollIntoView({block:"center"});
}

/* Formulaire de devis (#fd) */
function initDevis(cfg){
  const f=document.getElementById("fd");if(!f)return;fillWilaya(f.querySelector("[name=wilaya]"));
  f.addEventListener("submit",async e=>{e.preventDefault();
    const fd=new FormData(f),g=n=>String(fd.get(n)||"").trim();
    const name=g("name"),phone=cleanPhone(g("phone")),wilaya=g("wilaya"),qty=g("qty"),company=g("company"),email=g("email"),message=g("message"),variant=g("variant");
    const ok=[mark(f.querySelector(".f-name"),name.length>=3),mark(f.querySelector(".f-phone"),/^0[567]\d{8}$/.test(phone)),mark(f.querySelector(".f-wilaya"),!!wilaya),mark(f.querySelector(".f-qty"),+qty>=1)];
    if(email)ok.push(mark(f.querySelector(".f-email"),/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)));
    if(ok.includes(false)){f.querySelector(".invalid input,.invalid select").focus();return;}
    const b=f.querySelector("button[type=submit]");b.disabled=true;b.textContent="جارٍ الإرسال…";
    const product="[DEVIS] "+cfg.product+(variant?" – "+variant:"");
    const address=["Entreprise: "+(company||"—"),"Email: "+(email||"—"),"Message: "+(message||"—")].join(" | ");
    try{await send({type:"devis",name,phone,wilaya,address,qty,total:"",product,company,email,message,variant});
      window.fbq&&fbq("track","Lead",{content_name:product,content_category:"devis",num_items:+qty});
      finish(cfg.root,document.getElementById("doneDevis"),name,phone);
    }catch(err){b.disabled=false;b.textContent="إرسال الطلب";alert("تعذر الإرسال. تحقق من اتصالك بالإنترنت وحاول مرة أخرى.");}
  });
}

/* Formulaire de réservation pour produits en arrivage (#fr) */
function initReserve(cfg){
  const f=document.getElementById("fr");if(!f)return;fillWilaya(f.querySelector("[name=wilaya]"));
  let q=1;const out=f.querySelector(".q-out");
  f.querySelector(".q-plus").onclick=()=>{if(q<500){q++;out.textContent=q;}};
  f.querySelector(".q-minus").onclick=()=>{if(q>1){q--;out.textContent=q;}};
  f.addEventListener("submit",async e=>{e.preventDefault();
    const fd=new FormData(f),g=n=>String(fd.get(n)||"").trim();
    const name=g("name"),phone=cleanPhone(g("phone")),wilaya=g("wilaya"),variant=g("variant"),size=g("size");
    const ok=[mark(f.querySelector(".f-name"),name.length>=3),mark(f.querySelector(".f-phone"),/^0[567]\d{8}$/.test(phone)),mark(f.querySelector(".f-wilaya"),!!wilaya)];
    if(ok.includes(false)){f.querySelector(".invalid input,.invalid select").focus();return;}
    const b=f.querySelector("button[type=submit]");b.disabled=true;b.textContent="جارٍ الإرسال…";
    const product="[ARRIVAGE] "+cfg.product+(variant?" – "+variant:"")+(size?" – P"+size:"");
    try{await send({type:"reservation",name,phone,wilaya,address:"Réservation – à rappeler à l'arrivage",qty:String(q),total:"",product,variant,size});
      window.fbq&&fbq("track","Lead",{content_name:product,content_category:"reservation",num_items:q});
      finish(cfg.root,document.getElementById("doneReserve"),name,phone);
    }catch(err){b.disabled=false;b.textContent="احجز الآن";alert("تعذر الإرسال. تحقق من اتصالك بالإنترنت وحاول مرة أخرى.");}
  });
}
document.addEventListener("input",e=>{const fl=e.target.closest&&e.target.closest(".invalid");if(fl)fl.classList.remove("invalid");});
document.addEventListener("change",e=>{const fl=e.target.closest&&e.target.closest(".invalid");if(fl)fl.classList.remove("invalid");});
window.HSE={initModes,initDevis,initReserve,fillWilaya,cleanPhone};
})();
