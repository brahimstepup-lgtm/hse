/* Service HSE — animations partagées (accueil, pages produit, Gestion EPI). */
(function(){
"use strict";
var d=document,root=d.documentElement;
var reduce=window.matchMedia&&matchMedia("(prefers-reduced-motion:reduce)").matches;
var fine=window.matchMedia&&matchMedia("(hover:hover) and (pointer:fine)").matches;
if(!("IntersectionObserver" in window))return;
function $$(s,c){return Array.prototype.slice.call((c||d).querySelectorAll(s));}
function tag(sel,kind,step,base){$$(sel).forEach(function(el,i){if(el.hasAttribute("data-mo"))return;el.setAttribute("data-mo",kind);
  if(kind==="wipe"&&!el.querySelector(".mo-line"))el.innerHTML='<span class="mo-line"><span>'+el.innerHTML+"</span></span>";
  var k=step?(i%8)*step:0;el.style.setProperty("--d",((base||0)+k).toFixed(2)+"s");});}
function group(parentSel,childSel,kind,step){$$(parentSel).forEach(function(p){$$(childSel,p).forEach(function(el,i){if(el.hasAttribute("data-mo"))return;
  el.setAttribute("data-mo",kind);el.style.setProperty("--d",(Math.min(i,9)*step).toFixed(2)+"s");});});}

function init(){
  root.classList.add("mo");
  var home=!!d.getElementById("heroRot"),product=!!d.querySelector("main.hero .gal"),epi=!!d.getElementById("vSessions");

  /* ----- barre de progression ----- */
  var bar=d.createElement("div");bar.className="mo-progress";bar.setAttribute("aria-hidden","true");d.body.appendChild(bar);
  var hdr=d.querySelector("header"),tick=false;
  function onScroll(){if(tick)return;tick=true;requestAnimationFrame(function(){tick=false;
    var h=root.scrollHeight-innerHeight;bar.style.setProperty("--mo-p",h>0?Math.min(1,scrollY/h):0);
    if(hdr)hdr.classList.toggle("mo-scrolled",scrollY>30);road();
    clearTimeout(sweepT);sweepT=setTimeout(sweep,220);});}
  var sweepT;function sweep(){$$("[data-mo]:not(.in),.h2:not(.in),.mock:not(.in)").forEach(function(el){if(el.offsetParent&&el.getBoundingClientRect().top<innerHeight*0.95)el.classList.add("in");});}
  addEventListener("scroll",onScroll,{passive:true});addEventListener("resize",onScroll);

  /* ----- titres du hero : lignes qui montent ----- */
  $$(".hero h1").forEach(function(h){if(product||h.querySelector(".mo-line"))return;
    var parts=h.innerHTML.split(/<br\s*\/?>/i);
    h.innerHTML=parts.map(function(p,i){return '<span class="mo-line" style="--d:'+(0.15+i*0.14)+'s"><span style="--d:'+(0.15+i*0.14)+'s">'+p+"</span></span>";}).join("");
    requestAnimationFrame(function(){requestAnimationFrame(function(){$$(".mo-line",h).forEach(function(l){l.classList.add("in");});});});});

  if(home){
    scene(d.querySelector(".hero"));
    marquee(d.querySelector(".trust"));
    tag(".hero .kicker","rise",0,0.05);tag(".hero .wrap>div:first-child>p","rise",0.12,0.5);tag(".hero .cta","rise",0,0.8);tag(".hero-rot","pop",0,0.35);
    tag(".h2","wipe",0,0);tag(".lead","rise",0,0.15);
    group(".three",".card","rise",0.1);group(".arr-grid",".arr","pop",0.05);
    tag(".app-grid>div:first-child .free-badge","pop",0,0);group(".feat","li","left",0.12);tag(".app-grid>div:first-child>.btn","rise",0,0.3);tag(".mock","right",0,0.1);
    group(".steps",".step","rise",0.14);tag(".b2b","pop",0,0);
    buildRoad();countPrices();
    var cta=d.getElementById("heroCta");if(cta)cta.classList.add("mo-attn");
    if(fine&&!reduce)tilt($$(".card"),6);
  }
  if(product){
    tag("main.hero .gal","pop",0,0.05);
    var info=d.querySelector("main.hero .grid>div:not(.media)");
    if(info)Array.prototype.forEach.call(info.children,function(el,i){if(el.tagName==="UL"){el.querySelectorAll("li").forEach(function(li,j){li.setAttribute("data-mo","rise");li.style.setProperty("--d",(0.35+j*0.09)+"s");});return;}
      el.setAttribute("data-mo","rise");el.style.setProperty("--d",(0.12+Math.min(i,6)*0.08)+"s");});
    var pr=d.querySelector(".price");if(pr)pr.classList.add("mo-pop");
    tag(".order-in","rise",0,0);tag(".uses h2","wipe",0,0);group(".chips","span","pop",0.06);group(".faq","details","rise",0.07);
    tag(".seo-fr h2","wipe",0,0);tag(".seo-fr p,.seo-fr ul","rise",0.06,0.1);
    var main=d.querySelector("main.hero .btn,main.hero .quote-link");var ob=d.querySelector(".order button[type=submit]");if(ob)ob.classList.add("mo-attn");
  }
  if(epi){tag("#vSessions .free","pop",0,0);tag("#vSessions .hero p","rise",0.12,0.45);tag("#vSessions .pts","rise",0,0.75);group(".sess-grid",".box","rise",0.14);}

  /* ----- observateur ----- */
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target);}});},{rootMargin:"0px 0px -8% 0px",threshold:0.08});
  $$("[data-mo],.h2,.mock").forEach(function(el){io.observe(el);});
  /* filet de sécurité : rien ne reste invisible */
  setTimeout(function(){$$("[data-mo]:not(.in)").forEach(function(el){var r=el.getBoundingClientRect();if(r.top<innerHeight&&r.bottom>0)el.classList.add("in");});},2500);
  onScroll();
}

/* ----- scène du hero : un plan de site qui se sécurise ----- */
function scene(hero){if(!hero)return;
  var s='<svg class="mo-scene" viewBox="0 0 1200 620" preserveAspectRatio="xMidYMid slice" aria-hidden="true">'
  +'<defs><pattern id="moG" width="48" height="48" patternUnits="userSpaceOnUse"><path d="M48 0H0V48" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="1"/></pattern></defs>'
  +'<g class="grid"><rect x="-60" y="-60" width="1320" height="740" fill="url(#moG)"/></g>'
  +'<g class="par" style="--k:6px"><path class="walls" pathLength="1" d="M90 70H1110V550H90ZM90 300H420V550M420 70V190M700 70V330H1110M700 440V550M420 300H560"/></g>'
  +'<g class="par" style="--k:10px"><path class="route" d="M70 590H650V205H1132V292"/>'
  +'<g class="pic" style="animation-delay:2.1s"><path d="M1132 306l-11-17h22z" fill="#2fbf78"/></g></g>'
  +'<g class="par" style="--k:22px"><g class="fl"><g transform="translate(1136 410)"><g class="pic" style="animation-delay:.9s"><circle r="34" fill="#0a5cc4"/><path d="M-18 8a18 18 0 0 1 36 0zM-22 8h44v5h-44zM-3-12h6v12h-6z" fill="#fff"/></g></g></g></g>'
  +'<g class="par" style="--k:16px"><g class="fl b"><g transform="translate(650 310)"><g class="pic" style="animation-delay:1.15s"><rect x="-30" y="-30" width="60" height="60" rx="8" fill="#c8202b"/><path d="M-7-12h14v28h-14zM-3-20h6v8h-6zM7-16h9v4H7z" fill="#fff"/></g></g></g></g>'
  +'<g class="par" style="--k:28px"><g class="fl c"><g transform="translate(1136 545)"><g class="pic" style="animation-delay:1.4s"><path d="M0-38 40 30H-40z" fill="#f2c230" stroke="#14201a" stroke-width="5" stroke-linejoin="round"/><path d="M-3-14h6v24h-6zM-3 15h6v6h-6z" fill="#14201a"/></g></g></g></g>'
  +'<g class="par" style="--k:14px"><g class="fl b"><g transform="translate(650 480)"><g class="pic" style="animation-delay:1.65s"><rect x="-38" y="-26" width="76" height="52" rx="8" fill="#0d7a44"/><path d="M0 18v-30m-12 12 12-14 12 14" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></g></g></g></g>'
  +'<g class="par" style="--k:18px"><g class="fl c"><g transform="translate(58 330)"><g class="pic" style="animation-delay:1.9s"><rect x="-26" y="-26" width="52" height="52" rx="8" fill="#0d7a44"/><path d="M-14 0h28M0-14v28" stroke="#fff" stroke-width="7"/></g></g></g></g>'
  +'<g transform="translate(1132 292)"><circle class="ping" r="14"/><circle class="ping" r="14" style="animation-delay:1.3s"/></g>'
  +'</svg>';
  hero.insertAdjacentHTML("afterbegin",s);
  if(fine&&!reduce){var sc=hero.querySelector(".mo-scene");hero.addEventListener("pointermove",function(e){var r=hero.getBoundingClientRect();
    sc.style.setProperty("--mx",((e.clientX-r.left)/r.width-.5).toFixed(3));sc.style.setProperty("--my",((e.clientY-r.top)/r.height-.5).toFixed(3));});}
}

/* ----- ruban défilant ----- */
function marquee(t){if(!t)return;var ul=t.querySelector("ul");if(!ul)return;
  var ar=["التوصيل إلى 69 ولاية","الدفع عند الاستلام","أسعار خاصة للشركات","أدوات HSE مجانية"];
  var lis=$$("li",ul);lis.forEach(function(li,i){if(ar[i]){var a=d.createElement("li");a.lang="ar";a.dir="rtl";a.textContent=ar[i];li.after(a);}});
  ul.classList.remove("wrap");
  var track=d.createElement("div");track.className="mo-track";
  var a=ul.cloneNode(true),b=ul.cloneNode(true);b.setAttribute("aria-hidden","true");
  /* assez large pour les grands écrans */
  a.innerHTML+=a.innerHTML;b.innerHTML=a.innerHTML;
  $$("li",a).slice(lis.length*2).forEach(function(li){li.setAttribute("aria-hidden","true");});
  track.appendChild(a);track.appendChild(b);ul.replaceWith(track);t.classList.add("mo-marquee");
}

/* ----- route de livraison au-dessus des étapes ----- */
var roadEl=null,stepEls=[];
function buildRoad(){var st=d.querySelector(".steps");if(!st)return;stepEls=$$(".step",st);
  roadEl=d.createElement("div");roadEl.className="mo-road";roadEl.setAttribute("aria-hidden","true");
  roadEl.innerHTML='<i class="pin" style="left:8%"></i><i class="pin" style="left:50%"></i><i class="pin" style="left:92%"></i>'
   +'<i class="mo-truck"><svg viewBox="0 0 70 40"><rect x="2" y="6" width="40" height="22" rx="3" fill="#f2c230"/><path d="M42 12h13l9 9v7H42z" fill="#0d7a44"/><path d="M46 15h8l5 6H46z" fill="#cfe9dc"/><rect x="2" y="26" width="62" height="4" fill="#0a5c33"/>'
   +'<g class="wh"><circle cx="16" cy="32" r="6" fill="#fff"/><path d="M16 27v10M11 32h10" stroke="#14201a" stroke-width="2"/></g><g class="wh"><circle cx="52" cy="32" r="6" fill="#fff"/><path d="M52 27v10M47 32h10" stroke="#14201a" stroke-width="2"/></g>'
   +'<path d="M9 13h26M9 18h18" stroke="#14201a" stroke-width="2.4" stroke-linecap="round"/></svg></i>';
  st.parentNode.insertBefore(roadEl,st);}
function road(){if(!roadEl)return;var r=roadEl.getBoundingClientRect(),vh=innerHeight;
  var p=Math.max(0,Math.min(1,(vh*0.92-r.top)/(vh*0.62)));roadEl.style.setProperty("--p",p.toFixed(3));
  var pins=roadEl.querySelectorAll(".pin"),th=[0.08,0.5,0.92];
  th.forEach(function(t,i){var on=p>=t-0.03;pins[i].classList.toggle("on",on);if(stepEls[i])stepEls[i].classList.toggle("mo-on",on&&(i===2||p<th[i+1]-0.03));});}

/* ----- prix qui défilent ----- */
function countPrices(){if(reduce)return;var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;io.unobserve(e.target);
  var el=e.target,txt=el.textContent,m=txt.match(/\d[\d\s]*/);if(!m)return;var end=parseInt(m[0].replace(/\s/g,""),10);if(!end)return;
  var t0=performance.now(),dur=900;(function f(t){var k=Math.min(1,(t-t0)/dur),v=Math.round(end*(1-Math.pow(1-k,3))/50)*50;
    el.textContent=txt.replace(m[0],(k<1?v:end)+(/\s$/.test(m[0])?" ":""));if(k<1)requestAnimationFrame(f);})(t0);});},{threshold:0.6});
  $$(".three .card .price").forEach(function(el){io.observe(el);});}

/* ----- inclinaison 3D des cartes ----- */
function tilt(els,max){els.forEach(function(el){
  el.addEventListener("pointermove",function(e){var r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
    el.style.transform="perspective(900px) rotateX("+(-y*max).toFixed(2)+"deg) rotateY("+(x*max).toFixed(2)+"deg) translateY(-6px)";});
  el.addEventListener("pointerleave",function(){el.style.transform="";});});}

if(d.readyState==="loading")d.addEventListener("DOMContentLoaded",init);else init();
})();
